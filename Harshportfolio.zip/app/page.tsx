"use client"

import Navbar from "@/components/ui/navbar"
import Hero from "@/components/sections/hero"
import About from "@/components/sections/about"
import Skills from "@/components/sections/skills"
import Projects from "@/components/sections/projects"
import Certificates from "@/components/sections/certificates"
import Contact from "@/components/sections/contact"
import { ShootingStars } from "@/components/ui/shooting-stars"
import { HeroScrollSection } from "@/components/sections/hero-scroll"
import { SkillsScrollSection } from "@/components/sections/skills-scroll"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-gray-100 overflow-hidden relative">
      {/* Background Elements */}
      <div className="fixed inset-0 bg-[url('/grid.svg')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))]"></div>

      {/* Shooting Stars Background Effect */}
      <div className="fixed inset-0 z-0">
        {/* Multiple layers of shooting stars with teal theme colors */}
        <ShootingStars
          starColor="#14b8a6"
          trailColor="#0d9488"
          minSpeed={15}
          maxSpeed={35}
          minDelay={1000}
          maxDelay={3000}
        />
        <ShootingStars
          starColor="#2dd4bf"
          trailColor="#14b8a6"
          minSpeed={10}
          maxSpeed={25}
          minDelay={2000}
          maxDelay={4000}
        />
        <ShootingStars
          starColor="#5eead4"
          trailColor="#2dd4bf"
          minSpeed={20}
          maxSpeed={40}
          minDelay={1500}
          maxDelay={3500}
        />
      </div>

      {/* Static Stars Background */}
      <div className="fixed inset-0 z-0">
        <div className="stars absolute inset-0 opacity-30" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        <Navbar />
        <div className="container mx-auto px-4">
          <Hero />
          <About />
          <Skills />
          <Projects />
          <Certificates />
          <Contact />
          <HeroScrollSection />
          <SkillsScrollSection />
        </div>
      </div>

      <style jsx>{`
        .stars {
          background-image: 
            radial-gradient(2px 2px at 20px 30px, #14b8a6, rgba(0,0,0,0)),
            radial-gradient(2px 2px at 40px 70px, #2dd4bf, rgba(0,0,0,0)),
            radial-gradient(2px 2px at 50px 160px, #5eead4, rgba(0,0,0,0)),
            radial-gradient(2px 2px at 90px 40px, #14b8a6, rgba(0,0,0,0)),
            radial-gradient(2px 2px at 130px 80px, #2dd4bf, rgba(0,0,0,0)),
            radial-gradient(2px 2px at 160px 120px, #5eead4, rgba(0,0,0,0)),
            radial-gradient(2px 2px at 200px 50px, #0d9488, rgba(0,0,0,0)),
            radial-gradient(2px 2px at 250px 100px, #14b8a6, rgba(0,0,0,0));
          background-repeat: repeat;
          background-size: 300px 300px;
          animation: twinkle 8s ease-in-out infinite;
        }
        @keyframes twinkle {
          0% { opacity: 0.3; }
          50% { opacity: 0.6; }
          100% { opacity: 0.3; }
        }
      `}</style>
    </main>
  )
}
