"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { ExternalLink, Github } from "lucide-react"
import SectionHeading from "@/components/ui/section-heading"
import { GlowCard } from "@/components/ui/spotlight-card"
import { cn } from "@/lib/utils"

export default function Projects() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const projects = [
    {
      title: "Car Sales Analytics Dashboard",
      description:
        "Comprehensive automotive industry analysis for India 2024, featuring sales performance by manufacturer, body-type distribution, and market trends with 4.2M+ total sales tracked.",
      date: "Dec 2024",
      techStack: ["Power BI", "Data Analytics", "Automotive"],
      demoUrl: "https://github.com/7HarshModi/CarSalesDashboard",
      codeUrl: "#",
      imageSrc: "/images/car-sales-dashboard.png",
      glowColor: "blue" as const,
    },
    {
      title: "Business Insights Dashboard",
      description:
        "Interactive BI dashboard showing revenue trends, product-category performance, and sales metrics with dynamic filters for comprehensive business analysis.",
      date: "Nov 2024",
      techStack: ["Power BI", "Business Intelligence", "Data Visualization"],
      demoUrl: "#",
      codeUrl: "#",
      imageSrc: "/images/business-insights-dashboard.png",
      glowColor: "purple" as const,
    },
  ]

  return (
    <section id="projects" className="py-20 relative scroll-mt-16">
      <SectionHeading title="Projects" subtitle="Some of my recent work" />

      <div className="grid md:grid-cols-2 gap-8 justify-items-center">
        {projects.map((project, index) => (
          <div
            key={index}
            className={cn(
              "opacity-0 transform translate-y-8 transition-all duration-700",
              mounted && "opacity-100 translate-y-0",
            )}
            style={{
              transitionDelay: mounted ? `${index * 200}ms` : "0ms",
            }}
          >
            <GlowCard
              glowColor={project.glowColor}
              customSize={true}
              className="w-full max-w-md h-auto min-h-[500px] bg-gray-900/20"
            >
              <div className="flex flex-col h-full">
                {/* Project Image */}
                {project.imageSrc && (
                  <div className="h-48 w-full overflow-hidden rounded-lg mb-4">
                    <Image
                      src={project.imageSrc || "/placeholder.svg"}
                      alt={project.title}
                      width={400}
                      height={200}
                      className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                  </div>
                )}

                {/* Project Content */}
                <div className="flex flex-col flex-1 gap-4">
                  <header className="space-y-2">
                    <h3 className="text-xl font-semibold text-gray-200 hover:text-teal-400 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-gray-500">{project.date}</p>
                  </header>

                  <p className="flex-1 text-sm text-gray-400 leading-relaxed">{project.description}</p>

                  {/* Tech Stack */}
                  <div className="flex flex-wrap gap-2">
                    {project.techStack.map((tech) => (
                      <span
                        key={tech}
                        className="rounded-full bg-gray-800/60 px-3 py-1 text-xs text-teal-300 border border-gray-700/50"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Links */}
                  <div className="flex gap-4 pt-2">
                    {project.demoUrl && (
                      <a
                        href={project.demoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-sm text-teal-400 transition-colors hover:text-teal-300 hover:underline"
                      >
                        <ExternalLink size={16} />
                        <span>Live Demo</span>
                      </a>
                    )}
                    {project.codeUrl && (
                      <a
                        href={project.codeUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-sm text-teal-400 transition-colors hover:text-teal-300 hover:underline"
                      >
                        <Github size={16} />
                        <span>View Code</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </GlowCard>
          </div>
        ))}
      </div>
    </section>
  )
}
