"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Code, Briefcase, GraduationCap, MapPin } from "lucide-react"
import SectionHeading from "@/components/ui/section-heading"
import { cn } from "@/lib/utils"

export default function About() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const quickFacts = [
    {
      icon: <Code className="h-5 w-5 text-teal-400" />,
      title: "CSE student",
      description: "Passionate about Data Science & Analytics field.",
    },
    {
      icon: <Briefcase className="h-5 w-5 text-teal-400" />,
      title: "Data Analytics",
      description: "Learning about data science & analytics and improving my skill",
    },
    {
      icon: <GraduationCap className="h-5 w-5 text-teal-400" />,
      title: "Continuous Learner",
      description: "Always expanding knowledge and skills",
    },
    {
      icon: <MapPin className="h-5 w-5 text-teal-400" />,
      title: "Gujarat, India",
      description: "Based in India",
    },
  ]

  return (
    <section id="about" className="py-20 relative scroll-mt-16">
      <SectionHeading title="About Me" subtitle="Get to know me better" />

      <div className="grid md:grid-cols-2 gap-10 items-center">
        <div
          className={cn(
            "relative opacity-0 transform -translate-x-8 transition-all duration-1000",
            mounted && "opacity-100 translate-x-0",
          )}
        >
          <div className="relative w-full aspect-square max-w-md mx-auto">
            <div className="absolute inset-0 bg-gradient-to-tr from-teal-500/20 to-teal-300/20 rounded-2xl -rotate-6 transform scale-95"></div>
            <div className="absolute inset-0 bg-gray-900/80 backdrop-blur-sm rounded-2xl border border-gray-800/50"></div>
            <div className="relative h-full w-full overflow-hidden rounded-2xl">
              <Image
                src="/images/profile-new.jpg"
                alt="Harsh Modi"
                width={400}
                height={400}
                className="object-cover h-full w-full"
                priority
              />
            </div>
          </div>
        </div>

        <div
          className={cn(
            "space-y-6 opacity-0 transform translate-x-8 transition-all duration-1000 delay-300",
            mounted && "opacity-100 translate-x-0",
          )}
        >
          <div className="bg-gray-900/50 backdrop-blur-sm p-6 rounded-2xl border border-gray-800/50 shadow-lg">
            <p className="text-gray-300 leading-relaxed">
              I'm a passionate Computer Science &amp; Engineering student with a strong interest in data science and
              analytics. I enjoy exploring datasets, uncovering insights, and presenting them with compelling
              dashboards.
            </p>
            <p className="text-gray-300 leading-relaxed mt-4">
              My journey in tech is driven by curiosity and a desire to do analysis on different types of datasets. I'm
              constantly learning and adapting to new technologies to stay at the forefront of Data Analysis field.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {quickFacts.map((fact, index) => (
              <div
                key={index}
                className="flex items-start gap-3 bg-gray-900/40 backdrop-blur-sm p-4 rounded-xl border border-gray-800/50 hover:border-teal-500/40 transition-colors"
              >
                <div className="mt-1 shrink-0">{fact.icon}</div>
                <div>
                  <h4 className="text-sm font-medium text-gray-200">{fact.title}</h4>
                  <p className="text-xs text-gray-400">{fact.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
