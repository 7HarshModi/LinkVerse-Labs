"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Award, Calendar, Hash } from "lucide-react"
import SectionHeading from "@/components/ui/section-heading"
import { GlowCard } from "@/components/ui/spotlight-card"
import { cn } from "@/lib/utils"

export default function Certificates() {
  const [mounted, setMounted] = useState(false)
  const [selectedCertificate, setSelectedCertificate] = useState<string | null>(null)

  useEffect(() => setMounted(true), [])

  const certificates = [
    {
      icon: "🤖",
      title: "ChatGPT for Data Analytics",
      organization: "Simplilearn SkillUp",
      description:
        "Completed comprehensive training on using ChatGPT and AI tools for data analysis and insights generation",
      image: "/images/chatgpt-data-analytics-certificate.jpg",
      date: "Jun 2025",
      code: "8418067",
      glowColor: "green" as const,
    },
    {
      icon: "🧠",
      title: "AI-ML Virtual Internship",
      organization: "AWS Academy | AICTE | EduSkills",
      description:
        "Successfully completed 10-week virtual internship in Artificial Intelligence and Machine Learning with AWS Academy curriculum",
      image: "/images/aws-internship-certificate.jpg",
      date: "Jan - Mar 2025",
      code: "2bb162cefdae6bcb4a6ef156993b56e4",
      glowColor: "orange" as const,
    },
    {
      icon: "📊",
      title: "Power BI for Beginners",
      organization: "Simplilearn SkillUp",
      description:
        "Completed comprehensive Power BI training course covering data visualization and business intelligence",
      image: "/images/power-bi-certificate.jpg",
      date: "Feb 2025",
      code: "7851036",
      glowColor: "blue" as const,
    },
    {
      icon: "📱",
      title: "Android Developer Virtual Internship",
      organization: "Google for Developers | AICTE | EduSkills",
      description:
        "Successfully completed 10-week virtual internship in Android Development supported by Google for Developers program",
      image: "/images/google-android-internship-certificate.jpg",
      date: "Oct - Dec 2024",
      code: "f685ac627660908d6ac62a950616476",
      glowColor: "purple" as const,
    },
  ]

  return (
    <section id="certificates" className="relative scroll-mt-16 py-20">
      <SectionHeading title="Certificates" subtitle="Recognition and accomplishments" />

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 justify-items-center">
        {certificates.map((cert, index) => (
          <div
            key={index}
            className={cn(
              "transform opacity-0 translate-y-8 transition-all duration-700",
              mounted && "translate-y-0 opacity-100",
            )}
            style={{ transitionDelay: mounted ? `${index * 150}ms` : "0ms" }}
          >
            <GlowCard
              glowColor={cert.glowColor}
              customSize={true}
              className="w-full max-w-sm h-auto min-h-[400px] bg-gray-900/20 cursor-pointer"
              onClick={() => cert.image && setSelectedCertificate(cert.image)}
            >
              <div className="flex flex-col h-full">
                {/* Certificate Icon and Title */}
                <div className="flex items-start gap-4 mb-4">
                  <div className="text-4xl">{cert.icon}</div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-200 hover:text-teal-400 transition-colors leading-tight">
                      {cert.title}
                    </h3>
                    <p className="text-sm text-teal-300 font-medium mt-1">{cert.organization}</p>
                  </div>
                </div>

                {/* Description */}
                <p className="flex-1 text-sm text-gray-400 leading-relaxed mb-4">{cert.description}</p>

                {/* Certificate Details */}
                <div className="space-y-3 mt-auto">
                  {cert.date && (
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Calendar className="w-4 h-4 text-teal-400" />
                      <span className="text-teal-400">Date:</span>
                      <span>{cert.date}</span>
                    </div>
                  )}
                  {cert.code && (
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Hash className="w-4 h-4 text-teal-400" />
                      <span className="text-teal-400">Certificate ID:</span>
                      <span className="font-mono">{cert.code}</span>
                    </div>
                  )}
                  {cert.image && (
                    <div className="flex items-center gap-2 text-xs text-teal-400 mt-3">
                      <Award className="w-4 h-4" />
                      <span>Click to view certificate</span>
                    </div>
                  )}
                </div>
              </div>
            </GlowCard>
          </div>
        ))}
      </div>

      {/* Certificate Modal */}
      {selectedCertificate && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
          onClick={() => setSelectedCertificate(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh] p-4">
            <button
              onClick={() => setSelectedCertificate(null)}
              className="absolute -top-2 -right-2 z-10 rounded-full bg-gray-900 p-2 text-white hover:bg-gray-800 transition-colors"
            >
              ✕
            </button>
            <Image
              src={selectedCertificate || "/placeholder.svg"}
              alt="Certificate"
              width={800}
              height={600}
              className="max-h-full max-w-full rounded-lg object-contain"
            />
          </div>
        </div>
      )}
    </section>
  )
}
