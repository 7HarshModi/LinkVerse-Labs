"use client"
import { ContainerScroll } from "@/components/ui/container-scroll-animation"
import Image from "next/image"

export function HeroScrollSection() {
  return (
    <section className="relative">
      <ContainerScroll
        titleComponent={
          <>
            <h2 className="text-4xl font-semibold text-gray-200 mb-4">
              Discover My <br />
              <span className="text-4xl md:text-[6rem] font-bold mt-1 leading-none text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-teal-200">
                Data Analytics Journey
              </span>
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              Explore interactive dashboards and data visualizations that tell compelling stories through data
            </p>
          </>
        }
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full p-4">
          {/* Car Sales Dashboard Preview */}
          <div className="relative group overflow-hidden rounded-xl border border-gray-700/50 bg-gray-800/30">
            <Image
              src="/images/car-sales-dashboard.png"
              alt="Car Sales Analytics Dashboard"
              width={600}
              height={400}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              draggable={false}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent" />
            <div className="absolute bottom-4 left-4 right-4">
              <h3 className="text-lg font-semibold text-white mb-2">Car Sales Analytics</h3>
              <p className="text-sm text-gray-300">Comprehensive automotive industry analysis for India 2024</p>
            </div>
          </div>

          {/* Business Insights Dashboard Preview */}
          <div className="relative group overflow-hidden rounded-xl border border-gray-700/50 bg-gray-800/30">
            <Image
              src="/images/business-insights-dashboard.png"
              alt="Business Insights Dashboard"
              width={600}
              height={400}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              draggable={false}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent" />
            <div className="absolute bottom-4 left-4 right-4">
              <h3 className="text-lg font-semibold text-white mb-2">Business Intelligence</h3>
              <p className="text-sm text-gray-300">Interactive BI dashboard with revenue trends and insights</p>
            </div>
          </div>
        </div>
      </ContainerScroll>
    </section>
  )
}
