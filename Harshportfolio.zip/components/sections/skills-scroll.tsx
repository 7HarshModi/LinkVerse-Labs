"use client"
import { ContainerScroll } from "@/components/ui/container-scroll-animation"
import { Code, BarChart3, Database, TrendingUp } from "lucide-react"

export function SkillsScrollSection() {
  const skillCategories = [
    {
      icon: <BarChart3 className="h-8 w-8" />,
      title: "Data Analytics",
      skills: ["Power BI", "Excel Advanced", "Data Visualization", "Statistical Analysis"],
      color: "from-teal-500 to-teal-400",
    },
    {
      icon: <Database className="h-8 w-8" />,
      title: "Data Management",
      skills: ["Data Cleaning", "Data Transformation", "ETL Processes", "Data Modeling"],
      color: "from-blue-500 to-blue-400",
    },
    {
      icon: <Code className="h-8 w-8" />,
      title: "Programming",
      skills: ["Python", "C++", "JavaScript", "SQL"],
      color: "from-purple-500 to-purple-400",
    },
    {
      icon: <TrendingUp className="h-8 w-8" />,
      title: "Business Intelligence",
      skills: ["Dashboard Design", "KPI Development", "Reporting", "Insights Generation"],
      color: "from-green-500 to-green-400",
    },
  ]

  return (
    <section className="relative">
      <ContainerScroll
        titleComponent={
          <>
            <h2 className="text-4xl font-semibold text-gray-200 mb-4">
              My Technical <br />
              <span className="text-4xl md:text-[6rem] font-bold mt-1 leading-none text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-teal-200">
                Skill Set
              </span>
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              A comprehensive overview of my data science and analytics capabilities
            </p>
          </>
        }
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full p-6">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className="relative group p-6 rounded-xl border border-gray-700/50 bg-gray-800/30 backdrop-blur-sm hover:border-teal-500/50 transition-all duration-300"
            >
              <div className={`inline-flex p-3 rounded-lg bg-gradient-to-r ${category.color} mb-4`}>
                <div className="text-white">{category.icon}</div>
              </div>

              <h3 className="text-xl font-semibold text-gray-200 mb-3">{category.title}</h3>

              <div className="space-y-2">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="flex items-center gap-2 text-sm text-gray-400">
                    <div className="w-2 h-2 rounded-full bg-teal-400" />
                    <span>{skill}</span>
                  </div>
                ))}
              </div>

              <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-teal-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
          ))}
        </div>
      </ContainerScroll>
    </section>
  )
}
