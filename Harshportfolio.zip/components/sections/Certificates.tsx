"use client"

import { useState, useEffect } from "react"
import SectionHeading from "@/components/ui/section-heading"
import CertificateCard from "@/components/ui/certificate-card"
import { cn } from "@/lib/utils"

export default function Certificates() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => setMounted(true), [])

  const certificates = [
    {
      icon: "📊",
      title: "Power BI for Beginners - Simplilearn SkillUp",
      description: "Completed comprehensive Power BI training course (Feb 2025)",
      image: "/images/power-bi-certificate.jpg",
      date: "Feb 2025",
      code: "7851036",
    },
    
  ]

  return (
    <section id="certificates" className="relative scroll-mt-16 py-20">
      <SectionHeading title="Certificates" subtitle="Recognition and accomplishments" />

      <div className="grid gap-6 md:grid-cols-2">
        {certificates.map((cert, index) => (
          <div
            key={index}
            className={cn(
              "transform opacity-0 translate-y-8 transition-all duration-700",
              mounted && "translate-y-0 opacity-100",
            )}
            style={{ transitionDelay: mounted ? `${index * 150}ms` : "0ms" }}
          >
            <CertificateCard
              icon={cert.icon}
              title={cert.title}
              description={cert.description}
              image={cert.image}
              date={cert.date}
              code={cert.code}
            />
          </div>
        ))}
      </div>
    </section>
  )
}
