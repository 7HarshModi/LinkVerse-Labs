"use client"

import { useState } from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface CertificateCardProps {
  icon: string
  title: string
  description?: string
  image?: string
  date?: string
  code?: string
}

export default function CertificateCard({ icon, title, description, image, date, code }: CertificateCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [showImage, setShowImage] = useState(false)

  return (
    <>
      <div
        className="group relative overflow-hidden rounded-xl border border-gray-800/50 bg-gray-900/30 p-6 backdrop-blur-sm transition-all duration-300 hover:border-teal-500/50 cursor-pointer"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={() => image && setShowImage(true)}
      >
        {/* Glow effect */}
        <div
          className={cn(
            "absolute inset-0 scale-0 rounded-full bg-teal-500/10 blur-xl transition-transform duration-700",
            isHovered && "scale-100",
          )}
        />

        <div className="relative z-10 flex items-start gap-4">
          <div className="text-2xl">{icon}</div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-200 transition-colors group-hover:text-teal-400">{title}</h3>
            {description && <p className="mt-1 text-sm text-gray-400">{description}</p>}
            {date && <p className="mt-2 text-xs text-teal-300">{date}</p>}
            {code && <p className="text-xs text-gray-500">Certificate Code: {code}</p>}
            {image && <p className="mt-2 text-xs text-teal-400">Click to view certificate</p>}
          </div>
        </div>
      </div>

      {/* Certificate Modal */}
      {showImage && image && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
          onClick={() => setShowImage(false)}
        >
          <div className="relative max-w-4xl max-h-[90vh] p-4">
            <button
              onClick={() => setShowImage(false)}
              className="absolute -top-2 -right-2 z-10 rounded-full bg-gray-900 p-2 text-white hover:bg-gray-800"
            >
              ✕
            </button>
            <Image
              src={image || "/placeholder.svg"}
              alt={title}
              width={800}
              height={600}
              className="max-h-full max-w-full rounded-lg object-contain"
            />
          </div>
        </div>
      )}
    </>
  )
}
