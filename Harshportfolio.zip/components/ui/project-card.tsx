"use client"

import { useState } from "react"
import Image from "next/image"
import { ExternalLink, Github } from "lucide-react"
import { cn } from "@/lib/utils"

interface ProjectCardProps {
  title: string
  description: string
  date: string
  techStack: string[]
  demoUrl?: string
  codeUrl?: string
  imageSrc?: string
}

export default function ProjectCard({
  title,
  description,
  date,
  techStack,
  demoUrl,
  codeUrl,
  imageSrc,
}: ProjectCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className="group flex h-full flex-col overflow-hidden rounded-xl border border-gray-800/50 bg-gray-900/30 backdrop-blur-sm transition-all duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Top image (optional) */}
      {imageSrc && (
        <div className="h-48 w-full overflow-hidden">
          <Image
            src={imageSrc || "/placeholder.svg"}
            alt={title}
            width={800}
            height={400}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
      )}

      {/* Card body */}
      <div className="flex flex-1 flex-col gap-4 p-6">
        <header className="space-y-1">
          <h3 className="text-lg font-semibold text-gray-200 group-hover:text-teal-400 transition-colors">{title}</h3>
          <p className="text-xs text-gray-500">{date}</p>
        </header>

        <p className="flex-1 text-sm text-gray-400">{description}</p>

        {/* Tech stack badges */}
        <div className="flex flex-wrap gap-2">
          {techStack.map((tech) => (
            <span key={tech} className="rounded bg-gray-800/60 px-2 py-1 text-xs text-teal-300">
              {tech}
            </span>
          ))}
        </div>

        {/* Links */}
        <div className="mt-4 flex gap-4">
          {demoUrl && (
            <a
              href={demoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-sm text-teal-400 transition-colors hover:text-teal-300"
            >
              <ExternalLink size={16} />
              <span>Live&nbsp;Demo</span>
            </a>
          )}
          {codeUrl && (
            <a
              href={codeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-sm text-teal-400 transition-colors hover:text-teal-300"
            >
              <Github size={16} />
              <span>View&nbsp;Code</span>
            </a>
          )}
        </div>
      </div>

      {/* Hover underline */}
      <div
        className={cn(
          "h-1 origin-left bg-gradient-to-r from-teal-500 to-teal-300 transition-transform duration-500",
          isHovered ? "scale-x-100" : "scale-x-0",
        )}
      />
    </div>
  )
}
